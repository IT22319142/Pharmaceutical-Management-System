package pharmacy;

 //  @author thath

public class Pharmacy 
{
    /**
     * @param args the command line arguments
     */
    
    
    public static void main(String[] args) 
    {
        // TODO code application logic here
    }
    
}
